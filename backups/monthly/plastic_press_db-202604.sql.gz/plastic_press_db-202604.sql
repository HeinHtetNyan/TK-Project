--
-- PostgreSQL database dump
--

\restrict HtUB8t0zSnRMCN12STpiCbPQwJi0DA5fUMpihTPToYKvpKStWZVGeDEd4mescBa

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.paymentmethod AS ENUM (
    'CASH',
    'BANK_TRANSFER',
    'KBZPAY'
);


ALTER TYPE public.paymentmethod OWNER TO "user";

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'STAFF'
);


ALTER TYPE public.userrole OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO "user";

--
-- Name: auditlog; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.auditlog (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id character varying NOT NULL,
    details character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.auditlog OWNER TO "user";

--
-- Name: auditlog_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.auditlog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auditlog_id_seq OWNER TO "user";

--
-- Name: auditlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.auditlog_id_seq OWNED BY public.auditlog.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    phone_numbers character varying,
    client_id character varying
);


ALTER TABLE public.customer OWNER TO "user";

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_seq OWNER TO "user";

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.item (
    id integer NOT NULL,
    voucher_id integer NOT NULL,
    lb double precision NOT NULL,
    plastic_size character varying NOT NULL,
    plastic_price double precision NOT NULL,
    color character varying NOT NULL,
    color_price double precision NOT NULL,
    total_price double precision NOT NULL
);


ALTER TABLE public.item OWNER TO "user";

--
-- Name: item_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_id_seq OWNER TO "user";

--
-- Name: item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.item_id_seq OWNED BY public.item.id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    amount_paid double precision NOT NULL,
    payment_date date NOT NULL,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    payment_method character varying,
    client_id character varying
);


ALTER TABLE public.payment OWNER TO "user";

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_id_seq OWNER TO "user";

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.payment.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying NOT NULL,
    password_hash character varying NOT NULL,
    role public.userrole NOT NULL,
    created_at timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."user" OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: voucher; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.voucher (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    voucher_number character varying NOT NULL,
    voucher_date date NOT NULL,
    items_total double precision NOT NULL,
    previous_balance double precision NOT NULL,
    final_total double precision NOT NULL,
    paid_amount double precision NOT NULL,
    remaining_balance double precision NOT NULL,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    payment_method character varying,
    client_id character varying
);


ALTER TABLE public.voucher OWNER TO "user";

--
-- Name: voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.voucher_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.voucher_id_seq OWNER TO "user";

--
-- Name: voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.voucher_id_seq OWNED BY public.voucher.id;


--
-- Name: auditlog id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.auditlog ALTER COLUMN id SET DEFAULT nextval('public.auditlog_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: item id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item ALTER COLUMN id SET DEFAULT nextval('public.item_id_seq'::regclass);


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.payment ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: voucher id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.voucher ALTER COLUMN id SET DEFAULT nextval('public.voucher_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.alembic_version (version_num) FROM stdin;
a1b2c3d4e5f6
\.


--
-- Data for Name: auditlog; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.auditlog (id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
1	1	CREATE_BULK	Payment	17	Bulk Payment of 500000.0 for customer 8	2026-04-15 02:01:45.166356
2	1	CREATE_BULK	Payment	18	Bulk Payment of 300000.0 for customer 11	2026-04-15 02:02:54.710178
3	1	CREATE	Voucher	V20	Voucher #V20 created	2026-04-15 02:14:09.51172
4	1	CREATE	Payment	None	Payment of 200000.0 for customer 13	2026-04-15 02:16:59.923798
5	1	CREATE_BULK	Payment	20	Bulk Payment of 150000.0 for customer 13	2026-04-15 02:17:10.399004
6	1	CREATE	Voucher	V21	Voucher #V21 created	2026-04-15 02:18:09.405859
7	1	CREATE	Payment	None	Payment of 1000000.0 for customer 13	2026-04-15 02:18:37.782388
8	1	CREATE	Payment	None	Payment of 1000000.0 for customer 13	2026-04-15 02:19:02.577885
11	1	CREATE	Voucher	V25	Voucher #V25 created	2026-04-15 14:02:26.934312
12	1	CREATE	Payment	23	Payment of 10000.0 for customer 14	2026-04-15 14:02:39.171668
13	1	CREATE	Voucher	V-001	Voucher #V-001 created	2026-04-15 16:57:12.552523
14	1	CREATE_BULK	Payment	24	Bulk Payment of 25000.0 for customer 16	2026-04-15 16:58:02.879348
15	1	CREATE	Voucher	V111	Voucher #V111 created	2026-04-15 17:06:34.760646
16	1	CREATE	Voucher	1131	Voucher #1131 created	2026-04-15 17:55:36.171486
17	1	CREATE	Voucher	333	Voucher #333 created	2026-04-15 17:59:58.765255
18	1	CREATE_BULK	Payment	25	Bulk Payment of 2222222.0 for customer 19	2026-04-15 17:59:58.863448
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.customer (id, name, created_at, phone_numbers, client_id) FROM stdin;
1	Mg Mg	2026-04-14 23:29:37.230149	\N	\N
2	U Ba	2026-04-14 23:34:50.762537	\N	\N
3	Daw Mya	2026-04-14 23:34:50.762706	\N	\N
4	Ko Kyaw	2026-04-14 23:34:50.762755	\N	\N
5	Ma Su	2026-04-14 23:34:50.762797	\N	\N
6	U Hla	2026-04-14 23:34:50.762838	\N	\N
7	Daw Aye	2026-04-14 23:34:50.762869	\N	\N
8	Ko Tun	2026-04-14 23:34:50.762899	\N	\N
9	Ma Ni	2026-04-14 23:34:50.76294	\N	\N
10	U Win	2026-04-14 23:34:50.762976	\N	\N
11	Daw Tin	2026-04-14 23:34:50.763007	\N	\N
13	Ko Min	2026-04-15 02:13:29.6693	\N	\N
14	MG H	2026-04-15 14:01:48.724018	\N	\N
15	jj	2026-04-15 16:41:33.672933	\N	\N
16	Kmkl	2026-04-15 16:54:06.133364	\N	\N
17	Pyae Moe may lol	2026-04-15 17:01:59.925907	\N	5ed9d0c7-3469-4ed0-b25d-f10273e56da4
18	HHHN	2026-04-15 17:06:22.69568	\N	\N
19	MMM	2026-04-15 17:10:15.32541	\N	8165f2ad-a3b7-4bb0-8121-01db584a868a
\.


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.item (id, voucher_id, lb, plastic_size, plastic_price, color, color_price, total_price) FROM stdin;
1	1	100	10x15	1000	Red+Blue	2000	300000
2	4	100	10x20	1000	နီ+ပြာ	2000	300000
3	5	16.66	6x9	3064	Red	553	60259.22
4	5	31.34	5x8	2323	Red	243	80418.44
5	6	23.56	8x12	2571	Clear	553	73601.44
6	6	5.89	10x15	2566	Clear	244	16550.899999999998
7	6	16.59	8x12	2522	Yellow	712	53652.06
8	7	41.27	5x8	3092	Red	500	148241.84000000003
9	8	28.17	6x9	3388	Clear	347	105214.95000000001
10	8	30.24	10x15	3001	Red	588	108531.36
11	9	46.02	12x18	3265	Red	604	178051.38
12	10	7.39	5x8	2161	Clear	516	19783.03
13	10	34.73	8x12	2954	Blue	558	121971.76
14	10	21.01	12x18	3407	Red	350	78934.57
15	11	12.98	8x12	2324	Blue	310	34189.32
16	12	10.05	12x18	2961	Red	350	33275.55
17	13	37.58	8x12	1677	Yellow	754	91356.98
18	13	18.85	6x9	2963	White	324	61959.950000000004
19	14	12.63	12x18	2739	Clear	501	40921.200000000004
20	15	38.65	6x9	2641	Blue	241	111389.3
21	15	9.13	5x8	2112	Green	302	22039.820000000003
22	16	7.39	8x12	2471	Green	638	22975.51
23	17	20.82	6x9	2452	Yellow	597	63480.18
24	18	15.5	8x12	3147	Red	343	54095
25	18	43.23	5x8	3151	Yellow	530	159129.62999999998
26	19	47.43	8x12	2620	Green	503	148123.88999999998
27	19	41.45	5x8	2021	Green	593	108350.3
28	19	25.75	5x8	1655	Clear	546	56675.75
29	20	19.41	10x15	1691	Clear	707	46545.18
30	21	32.48	6x9	1546	White	332	60997.439999999995
31	21	7.19	5x8	1785	Blue	272	14789.83
32	22	12.56	8x12	3142	Blue	328	43583.200000000004
33	23	44.25	10x15	1720	Green	556	100713
34	23	12.08	5x8	2546	White	203	33207.92
35	23	7.24	8x12	1933	Blue	301	16174.16
36	24	31.74	10x15	2297	Clear	366	84523.62
37	25	9.92	12x18	1651	Clear	460	20941.12
38	25	8.07	10x15	1558	Blue	200	14187.060000000001
39	25	37.28	10x15	2369	Red	690	114039.52
40	26	39.01	10x15	3333	Red	406	145858.38999999998
41	26	24.57	12x18	3276	Yellow	703	97764.03
42	26	18.86	6x9	1734	Clear	426	40737.6
43	27	43.39	12x18	2129	Clear	404	109906.87
44	27	19.71	8x12	3399	Green	218	71291.07
45	27	46.13	6x9	2675	Red	415	142541.7
46	28	15.56	5x8	2547	Clear	431	46337.68
47	28	33.96	10x15	2800	Red	481	111422.76000000001
48	28	27.76	8x12	3136	Yellow	518	101435.04000000001
49	29	22.03	8x12	1958	White	410	52167.04
50	29	27.64	12x18	3110	White	391	96767.64
51	29	36.72	8x12	3260	Blue	728	146439.36
52	30	47.77	10x15	1950	Red	334	109106.68000000001
53	30	28.17	5x8	1594	Red	658	63438.840000000004
54	30	33.35	8x12	1691	Clear	428	70668.65000000001
55	31	29.07	12x18	2483	Yellow	382	83285.55
56	31	14.55	12x18	2270	White	217	36185.85
57	31	49.65	5x8	3133	Clear	317	171292.5
58	32	7.53	5x8	2306	White	221	19028.31
59	32	25.14	10x15	3143	Green	310	86808.42
60	32	41.15	12x18	1914	Yellow	462	97772.4
61	33	22.97	8x12	3292	Green	278	82002.9
62	33	36.53	10x15	2523	White	358	105242.93000000001
63	33	17.42	5x8	1736	Green	747	43253.86000000001
64	34	42.96	5x8	2533	Red	658	137085.36000000002
65	35	42.66	6x9	3406	White	525	167696.46
66	35	42.17	6x9	3446	Blue	779	178168.25
67	35	29.54	6x9	1882	Blue	568	72373
68	36	16.24	10x15	3475	Green	423	63303.52
69	36	42.62	12x18	2295	White	605	123597.99999999999
70	36	44.08	10x15	2819	Green	548	148417.36
74	38	17	10x15	2963	Clear	709	62424
75	38	42.72	6x9	3321	Clear	687	171221.76
76	38	16.54	8x12	2126	Green	560	44426.439999999995
77	39	29.21	10x15	2239	White	552	81525.11
78	39	5.56	5x8	1764	Red	338	11687.119999999999
79	40	5.34	5x8	3426	Clear	715	22112.94
80	41	13.65	12x18	2369	Green	749	42560.700000000004
81	41	38.14	6x9	1617	Red	251	71245.52
82	41	6.13	12x18	2387	White	461	17458.239999999998
83	42	19.46	10x15	2171	Blue	694	55752.9
84	42	14.67	12x18	3017	Green	218	47457.45
85	42	26.18	8x12	3048	Clear	368	89430.88
86	43	38.56	8x12	2634	Yellow	296	112980.8
87	43	40.94	6x9	3142	Blue	660	155653.88
88	44	41.74	6x9	1608	White	567	90784.5
89	45	100	10x30	5000	နီ+၀ါ	200	520000
90	46	1000	20x15	2000	ပြာ	500	2500000
91	49	100	10x20	1000	Red	1000	200000
92	50	10	Huge	5000	A net	2000	70000
93	51	1123	1312	312312	12312	12312312	14177452752
94	52	1312312	23112	12312	123123	13123	33378655720
95	53	222	222	222	222	222	98568
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.payment (id, customer_id, amount_paid, payment_date, note, created_at, payment_method, client_id) FROM stdin;
1	1	50000	2026-04-15		2026-04-14 23:30:30.946445	\N	\N
2	1	30000	2026-04-15		2026-04-14 23:32:45.597072	\N	\N
3	2	11053	2026-04-03	Direct payment 1	2026-04-14 23:34:50.80887	\N	\N
4	2	11606	2026-04-06	Direct payment 2	2026-04-14 23:34:50.808942	\N	\N
5	3	17146	2026-04-03	Direct payment 1	2026-04-14 23:34:50.825619	\N	\N
6	4	11433	2026-04-08	Direct payment 1	2026-04-14 23:34:50.837644	\N	\N
7	4	17631	2026-04-05	Direct payment 2	2026-04-14 23:34:50.837704	\N	\N
8	5	5351	2026-04-12	Direct payment 1	2026-04-14 23:34:50.845733	\N	\N
9	5	19449	2026-04-05	Direct payment 2	2026-04-14 23:34:50.845794	\N	\N
10	6	5716	2026-04-10	Direct payment 1	2026-04-14 23:34:50.860217	\N	\N
11	6	15932	2026-04-09	Direct payment 2	2026-04-14 23:34:50.860274	\N	\N
12	7	11610	2026-03-31	Direct payment 1	2026-04-14 23:34:50.871892	\N	\N
13	8	9309	2026-04-08	Direct payment 1	2026-04-14 23:34:50.883686	\N	\N
14	9	5709	2026-04-09	Direct payment 1	2026-04-14 23:34:50.894402	\N	\N
15	10	8508	2026-04-12	Direct payment 1	2026-04-14 23:34:50.904763	\N	\N
16	11	14287	2026-04-13	Direct payment 1	2026-04-14 23:34:50.912591	\N	\N
17	8	500000	2026-04-15		2026-04-15 02:01:45.162856	KBZPAY	\N
18	11	300000	2026-04-15		2026-04-15 02:02:54.708453	BANK_TRANSFER	\N
19	13	200000	2026-04-15		2026-04-15 02:16:59.923617	KBZPAY	\N
20	13	150000	2026-04-15		2026-04-15 02:17:10.397463	BANK_TRANSFER	\N
21	13	1000000	2026-04-15		2026-04-15 02:18:37.782245	KBZPAY	\N
22	13	1000000	2026-04-15		2026-04-15 02:19:02.577786	BANK_TRANSFER	\N
23	14	10000	2026-04-15		2026-04-15 14:02:39.159359	KBZPAY	c75e889b-7267-49cd-981c-eadadcf5bbb5
24	16	25000	2026-04-15	ခရေပေး	2026-04-15 16:58:02.877474	CASH	bfc8b705-44a6-45d9-b3a6-09469a204150
25	19	2222222	2026-04-15		2026-04-15 17:59:58.861868	KBZPAY	58c8353c-d454-467d-b084-6f78cc3465a1
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."user" (id, username, password_hash, role, created_at, is_active) FROM stdin;
1	admin	$2b$12$Zp2K2tG7DxPNm7Z1oxML9eVJ4AS5rTRe.k5xkjBX4P406EjHkgQHm	ADMIN	2026-04-14 16:58:46.244857	t
3	staff	$2b$12$XU1umM6lKVIlBj7MntjirepoHlmoFQAntF/UAjRCoN5mKr89cc95u	STAFF	2026-04-15 07:33:20.67907	t
\.


--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.voucher (id, customer_id, voucher_number, voucher_date, items_total, previous_balance, final_total, paid_amount, remaining_balance, note, created_at, updated_at, payment_method, client_id) FROM stdin;
1	1	V1	2026-04-14	300000	0	300000	200000	100000		2026-04-14 23:30:18.095583	2026-04-14 23:30:18.095608	\N	\N
4	1	V2	2026-04-15	300000	50000	350000	250000	100000		2026-04-14 23:32:32.333401	2026-04-14 23:32:32.333409	\N	\N
5	2	V-2-7734	2026-03-26	140677.66	0	140677.66	70338.83	70338.83	Sample voucher 1 for U Ba	2026-04-14 23:34:50.794892	2026-04-14 23:34:50.7949	\N	\N
6	2	V-2-7226	2026-03-18	143804.4	70338.83	214143.22999999998	71902.2	142241.02999999997	Sample voucher 2 for U Ba	2026-04-14 23:34:50.799368	2026-04-14 23:34:50.799376	\N	\N
7	2	V-2-5340	2026-03-25	148241.84000000003	142241.03	290482.87	74120.92	216361.95	Sample voucher 3 for U Ba	2026-04-14 23:34:50.801931	2026-04-14 23:34:50.801939	\N	\N
8	2	V-2-9787	2026-03-28	213746.31	216361.95	430108.26	213746.31	216361.95	Sample voucher 4 for U Ba	2026-04-14 23:34:50.804603	2026-04-14 23:34:50.80461	\N	\N
9	2	V-2-5147	2026-04-14	178051.38	216361.94999999995	394413.32999999996	178051.38	216361.94999999995	Sample voucher 5 for U Ba	2026-04-14 23:34:50.807066	2026-04-14 23:34:50.807074	\N	\N
10	3	V-3-7823	2026-04-04	220689.36	0	220689.36	110344.68	110344.68	Sample voucher 1 for Daw Mya	2026-04-14 23:34:50.811291	2026-04-14 23:34:50.811298	\N	\N
11	3	V-3-4925	2026-03-20	34189.32	110344.68	144534	34189.32	110344.68	Sample voucher 2 for Daw Mya	2026-04-14 23:34:50.815158	2026-04-14 23:34:50.815173	\N	\N
12	3	V-3-2099	2026-03-23	33275.55	110344.68	143620.22999999998	33275.55	110344.67999999998	Sample voucher 3 for Daw Mya	2026-04-14 23:34:50.818543	2026-04-14 23:34:50.818559	\N	\N
13	3	V-3-7774	2026-03-22	153316.93	110344.68	263661.61	76658.46	187003.14999999997	Sample voucher 4 for Daw Mya	2026-04-14 23:34:50.82174	2026-04-14 23:34:50.821747	\N	\N
14	3	V-3-1921	2026-04-08	40921.200000000004	187003.14999999997	227924.34999999998	40921.2	187003.14999999997	Sample voucher 5 for Daw Mya	2026-04-14 23:34:50.824067	2026-04-14 23:34:50.824076	\N	\N
15	4	V-4-2233	2026-03-24	133429.12	0	133429.12	0	133429.12	Sample voucher 1 for Ko Kyaw	2026-04-14 23:34:50.827187	2026-04-14 23:34:50.827194	\N	\N
16	4	V-4-1812	2026-04-12	22975.51	133429.12	156404.63	11487.75	144916.88	Sample voucher 2 for Ko Kyaw	2026-04-14 23:34:50.830804	2026-04-14 23:34:50.83082	\N	\N
17	4	V-4-2660	2026-03-25	63480.18	144916.88	208397.06	63480.18	144916.88	Sample voucher 3 for Ko Kyaw	2026-04-14 23:34:50.833762	2026-04-14 23:34:50.83377	\N	\N
18	4	V-4-7808	2026-03-18	213224.62999999998	144916.88	358141.51	0	358141.51	Sample voucher 4 for Ko Kyaw	2026-04-14 23:34:50.835911	2026-04-14 23:34:50.835919	\N	\N
19	5	V-5-7426	2026-04-13	313149.94	0	313149.94	156574.97	156574.97	Sample voucher 1 for Ma Su	2026-04-14 23:34:50.839345	2026-04-14 23:34:50.839352	\N	\N
20	5	V-5-4363	2026-04-04	46545.18	156574.97	203120.15	0	203120.15	Sample voucher 2 for Ma Su	2026-04-14 23:34:50.841698	2026-04-14 23:34:50.841707	\N	\N
21	5	V-5-6234	2026-03-24	75787.26999999999	203120.15	278907.42	75787.27	203120.14999999997	Sample voucher 3 for Ma Su	2026-04-14 23:34:50.843804	2026-04-14 23:34:50.843812	\N	\N
22	6	V-6-5885	2026-03-26	43583.200000000004	0	43583.200000000004	43583.2	7.275957614183426e-12	Sample voucher 1 for U Hla	2026-04-14 23:34:50.8474	2026-04-14 23:34:50.847408	\N	\N
23	6	V-6-8534	2026-04-04	150095.08	7.275957614183426e-12	150095.08	150095.08	0	Sample voucher 2 for U Hla	2026-04-14 23:34:50.850681	2026-04-14 23:34:50.850697	\N	\N
24	6	V-6-2343	2026-03-27	84523.62	2.9103830456733704e-11	84523.62000000002	42261.81	42261.81000000003	Sample voucher 3 for U Hla	2026-04-14 23:34:50.854053	2026-04-14 23:34:50.854061	\N	\N
25	6	V-6-6797	2026-04-07	149167.7	42261.810000000056	191429.51000000007	74583.85	116845.66000000006	Sample voucher 4 for U Hla	2026-04-14 23:34:50.856216	2026-04-14 23:34:50.856224	\N	\N
26	6	V-6-9406	2026-04-09	284360.01999999996	116845.66000000009	401205.68000000005	142180.01	259025.67000000004	Sample voucher 5 for U Hla	2026-04-14 23:34:50.858502	2026-04-14 23:34:50.858509	\N	\N
27	7	V-7-5018	2026-03-15	323739.64	0	323739.64	323739.64	0	Sample voucher 1 for Daw Aye	2026-04-14 23:34:50.861832	2026-04-14 23:34:50.861839	\N	\N
28	7	V-7-5603	2026-03-25	259195.48	0	259195.48	129597.74	129597.74	Sample voucher 2 for Daw Aye	2026-04-14 23:34:50.864099	2026-04-14 23:34:50.864107	\N	\N
29	7	V-7-8787	2026-04-09	295374.04	129597.73999999999	424971.77999999997	295374.04	129597.73999999999	Sample voucher 3 for Daw Aye	2026-04-14 23:34:50.866486	2026-04-14 23:34:50.866493	\N	\N
30	7	V-7-8832	2026-04-03	243214.17000000004	129597.73999999999	372811.91000000003	121607.09	251204.82000000004	Sample voucher 4 for Daw Aye	2026-04-14 23:34:50.868755	2026-04-14 23:34:50.868764	\N	\N
33	8	V-8-4369	2026-04-03	230499.69000000003	290763.9	521263.5900000001	0	521263.5900000001	Sample voucher 3 for Ko Tun	2026-04-14 23:34:50.880981	2026-04-14 23:34:50.880999	\N	\N
34	9	V-9-8390	2026-03-25	137085.36000000002	0	137085.36000000002	137085.36	2.9103830456733704e-11	Sample voucher 1 for Ma Ni	2026-04-14 23:34:50.885097	2026-04-14 23:34:50.885104	\N	\N
35	9	V-9-3980	2026-04-11	418237.70999999996	2.9103830456733704e-11	418237.70999999996	418237.71	-5.820766091346741e-11	Sample voucher 2 for Ma Ni	2026-04-14 23:34:50.887479	2026-04-14 23:34:50.887487	\N	\N
36	9	V-9-8462	2026-03-30	335318.88	-1.1641532182693481e-10	335318.8799999999	335318.88	-1.1641532182693481e-10	Sample voucher 3 for Ma Ni	2026-04-14 23:34:50.889899	2026-04-14 23:34:50.889907	\N	\N
38	10	V-10-7447	2026-04-13	278072.2	0	278072.2	278072.2	0	Sample voucher 1 for U Win	2026-04-14 23:34:50.895925	2026-04-14 23:34:50.895932	\N	\N
39	10	V-10-5227	2026-04-12	93212.23	0	93212.23	0	93212.23	Sample voucher 2 for U Win	2026-04-14 23:34:50.898339	2026-04-14 23:34:50.898346	\N	\N
40	10	V-10-2717	2026-03-21	22112.94	93212.22999999998	115325.16999999998	0	115325.16999999998	Sample voucher 3 for U Win	2026-04-14 23:34:50.900608	2026-04-14 23:34:50.900616	\N	\N
41	10	V-10-5274	2026-03-15	131264.46	115325.16999999998	246589.62999999998	0	246589.62999999998	Sample voucher 4 for U Win	2026-04-14 23:34:50.902749	2026-04-14 23:34:50.902757	\N	\N
42	11	V-11-2174	2026-03-18	192641.23	0	192641.23	192641.23	0	Sample voucher 1 for Daw Tin	2026-04-14 23:34:50.906288	2026-04-14 23:34:50.906296	\N	\N
31	8	V-8-1463	2026-03-20	290763.9	0	290763.9	290763.9	0	Sample voucher 1 for Ko Tun	2026-04-14 23:34:50.873939	2026-04-14 23:34:50.873946	\N	\N
32	8	V-8-4492	2026-03-26	203609.13	290763.9	494373.03	412845.23	81527.80000000005	Sample voucher 2 for Ko Tun	2026-04-14 23:34:50.87712	2026-04-14 23:34:50.877128	\N	\N
43	11	V-11-2414	2026-03-30	268634.68	0	268634.68	268634.68	0	Sample voucher 2 for Daw Tin	2026-04-14 23:34:50.908617	2026-04-14 23:34:50.908625	\N	\N
44	11	V-11-2417	2026-04-06	90784.5	268634.68000000005	359419.18000000005	31365.320000000007	328053.86000000004	Sample voucher 3 for Daw Tin	2026-04-14 23:34:50.910946	2026-04-14 23:34:50.910955	\N	\N
45	13	V20	2026-04-15	520000	0	520000	170000	350000		2026-04-15 02:14:09.511513	2026-04-15 02:14:09.511522	CASH	\N
46	13	V21	2026-04-15	2500000	0	2500000	499998	2000002		2026-04-15 02:18:09.405636	2026-04-15 02:18:09.405653	BANK_TRANSFER	\N
49	14	V25	2026-04-15	200000	0	200000	50000	150000		2026-04-15 14:02:26.934165	2026-04-15 14:02:26.934174	CASH	8ed98ecd-1995-43d3-9b0d-108efdf273dd
50	16	V-001	2026-04-15	70000	0	70000	45000	25000	Fuck off bitch hhn	2026-04-15 16:57:12.55235	2026-04-15 16:57:12.552359	CASH	44750363-0cec-456a-801f-9da48837a93f
51	18	V111	2026-04-15	14177452752	0	14177452752	12312311	14165140441		2026-04-15 17:06:34.760419	2026-04-15 17:06:34.760435	BANK_TRANSFER	519ad7c7-7989-4e71-a35f-3bee94e5d020
53	19	333	2026-04-15	98568	33378532597	33378631165	22222222222	11156408943		2026-04-15 17:59:58.765108	2026-04-15 17:59:58.765117	BANK_TRANSFER	7454d355-c204-4d62-871c-721dc77ea691
52	19	1131	2026-04-15	33378655720	0	33378655720	2345345	33376310375		2026-04-15 17:55:36.171236	2026-04-15 17:55:36.171256	BANK_TRANSFER	47d0a971-dfc3-4ee0-a789-346054ce9ede
\.


--
-- Name: auditlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.auditlog_id_seq', 18, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.customer_id_seq', 19, true);


--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.item_id_seq', 95, true);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.payment_id_seq', 25, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- Name: voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.voucher_id_seq', 53, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: auditlog auditlog_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.auditlog
    ADD CONSTRAINT auditlog_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: customer uq_customer_client_id; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT uq_customer_client_id UNIQUE (client_id);


--
-- Name: payment uq_payment_client_id; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT uq_payment_client_id UNIQUE (client_id);


--
-- Name: voucher uq_voucher_client_id; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.voucher
    ADD CONSTRAINT uq_voucher_client_id UNIQUE (client_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: voucher voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.voucher
    ADD CONSTRAINT voucher_pkey PRIMARY KEY (id);


--
-- Name: ix_customer_client_id; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_customer_client_id ON public.customer USING btree (client_id);


--
-- Name: ix_customer_name; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_customer_name ON public.customer USING btree (name);


--
-- Name: ix_payment_client_id; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_payment_client_id ON public.payment USING btree (client_id);


--
-- Name: ix_user_username; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_user_username ON public."user" USING btree (username);


--
-- Name: ix_voucher_client_id; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_voucher_client_id ON public.voucher USING btree (client_id);


--
-- Name: ix_voucher_voucher_number; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_voucher_voucher_number ON public.voucher USING btree (voucher_number);


--
-- Name: auditlog auditlog_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.auditlog
    ADD CONSTRAINT auditlog_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: item item_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.voucher(id);


--
-- Name: payment payment_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: voucher voucher_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.voucher
    ADD CONSTRAINT voucher_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- PostgreSQL database dump complete
--

\unrestrict HtUB8t0zSnRMCN12STpiCbPQwJi0DA5fUMpihTPToYKvpKStWZVGeDEd4mescBa

